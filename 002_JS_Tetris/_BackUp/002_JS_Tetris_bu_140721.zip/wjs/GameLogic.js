// # GameLogic Class
(function() {
	if (window.GameLogic != undefined) {
		return;
	}

	// #
	var t_class = window.GameLogic = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	//
	t_class.prototype = {

		// :: 초기화
		p_initOnce: function(owner) {
			this._owner = owner;
			this._cc = null;
			this._downSpeed = 1000;

			jQuery(document).keydown(HB_Adapter.wrap(this, this.p_keyDown));

			this._timer = new HB_Timer(this._downSpeed);
			this._timer.onCallBack = HB_Adapter.wrap(this, this.p_timer_onCallBack);
			//this._timer.start();
		}

		,
		p_keyDown: function(eObj) {
			//alert(eObj.keyCode);
		}

		,
		p_timer_onCallBack: function(eObj) {
			switch (eObj.type) {
				case HB_Timer.EVENT_TYPE_UPDATE: {
					alert('1');

					break;
				}

				case HB_Timer.EVENT_TYPE_UPDATE_END: {
					alert('2');

					break;
				}
			}
		}
	};

})();


// # CellCanvas Class
(function() {
	if (window.CellCanvas != undefined) {
		return;
	}

	// #
	var t_class = window.CellCanvas = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	//
	t_class.prototype = {

		// :: 초기화
		p_initOnce: function(owner) {
			// - Canvas 참조
			this._owner = owner;

			// - Cell Dictionary
			this._cellDic = null;

			// - Canvas 넓이
			this._canvasWidth = parseInt(this._owner.css('width'));
			// - Canvas 높이
			this._canvasHeight = parseInt(this._owner.css('height'));

			// - CellDefaultWidth
			this._cdw = 20;
			// - CellDefaultHeight
			this._cdh = 20;

			// - CellBaseX
			this._cbx = 20;
			// - CellBaseY
			this._cby = 20;

			// - CellMarginRight
			this._cmr = 20;
			// - CellMarginBottom
			this._cmb = 20;

			// - HorizontalLength
			this._hl = Math.floor(this._canvasWidth / this._cdw);
			// - VerticalLength
			this._vl = Math.floor(this._canvasHeight / this._cdh);
			// - TotalLength
			this._tl = this._hl * this._vl;

			// - NowShapeObj
			this._nso = null;
		}

		,
		// :: Cell 생성
		p_cellCreate: function() {
			var t_cell = new Cell(this._cdw, this._cdh);
			return t_rv;
		}

		,
		// :: Cells 생성
		p_cellsCreate: function() {
			this._cellDic = {};
			for (var i = 0; i < this._tl; i++) {
				var t_cell = this.p_cellCreate();
				var t_cx = i % this._hl;
				var t_cy = Math.floor(i / this._hl);
				var t_tx = Math.round((this._cdw + this._cmr) * t_cx);
				var t_ty = Math.round((this._cdh + this._cmb) * t_cy);
				var t_rx = this._cbx + t_tx;
				var t_ry = this._cby + t_ty;
				t_cell.set_x(t_rx);
				t_cell.set_y(t_ry);
				this._owner.append(t_cell.get_rect());

				t_cell.num = i + 1;//ThisNum
				t_cell.set_state(0);//StateNum


				var t_hn = t_cx + 1;
				var t_vn = t_cy + 1;
				var t_cName = 'cell_' + t_hn + '_' + t_vn;
				this._cellDic[t_cName] = t_cell;
			}
		}

		,
		// :: Shape 제거
		shapeClear: function() {
			if (this._nso != null) {
				this._nso = null;
			}
		}

		,
		// :: Shape 랜덤하기 생성
		shapeCreate: function() {
		}

		,
		// :: Shape 이동
		shapeMove: function(dir) {
		}

		,
		// :: Shape 회전
		shapeRotate: function(dir) {
		}

	};

})();

// # Cell Class
(function() {
	if (window.Cell != undefined) {
		return;
	}

	// #
	var t_class = window.Cell = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	// -
	t_class._RECT_COLORS = [
		'#ffffff', '#ff0000', '#33ff00', '#00FF99', '#3300ff', '#ff00cc', '#ffcc00', '#0099ff'
	];

	//
	t_class.prototype = {

		// :: 초기화
		p_initOnce: function(w, h) {
			//
			var t_DIV_STR =
				'<div style="position: absolute; left: 0px; top: 0px; ' +
					'overflow: hidden;"></div>';

			this._rect = jQuery(t_DIV_STR);
			this._rect.css('background-color', Cell._RECT_COLORS[1]);
			this._rect.css('width', w + 'px');
			this._rect.css('height', h + 'px');

			this._stateNum = 0;
		}

		,
		// ::
		get_rect: function() {
			return this._rect;
		}

		,
		// ::
		get_state: function() {
			return this._stateNum;
		}
		,
		// ::
		set_state: function(v) {
			this._stateNum = v;
		}


		,
		// ::
		get_x: function() {
			var t_v = parseInt(this._rect.css('left'));
			return t_v;
		}
		,
		// ::
		set_x: function(v) {
			this._rect.css('left', v + 'px');
		}

		,
		// ::
		get_y: function() {
			var t_v = parseInt(this._rect.css('top'));
			return t_v;
		}
		,
		// ::
		set_y: function(v) {
			this._rect.css('top', v + 'px');
		}

	};

})();


// # CellObj Class
(function() {
	if (window.CellObj != undefined) {
		return;
	}

	// #
	var t_class = window.CellObj = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	//
	t_class.prototype = {

		// :: 초기화
		p_initOnce: function(hn, vn, sn) {
			this.hn = hn;
			this.vn = vn;
			this.sn = sn;
		}

		,
		// :: 출력
		toString: function() {
			var t_str =
				'hn=' + this.hn + ', ' +
				'vn=' + this.vn + ', ' +
				'sn=' + this.sn;
			return t_str;
		}

		,
		// :: 복제
		clone: function() {
			var t_rv = new CellObj(this.hn, this.vn, this.sn);
			return t_rv;
		}

	};

})();


// # CellWorker Class
(function() {
	if (window.CellWorker != undefined) {
		return;
	}

	// #
	window.CellWorker = {

		// :: Cell 찾기
		get_cell: function(cellDic, hn, vn) {
			var t_rv = cellDic['cell_' + hn + '_' + vn];
			return t_rv;
		}

		,
		// :: Cell 상태가 변경할수 있는 상태인지 여부
		//		@Param(cellDic: CellDictionaryObject, hn: HorizontalNum, vn: VerticalNum)
		get_isState: function(cellDic, hn, vn) {
			var t_rv = false;

			var t_cell = this.get_cell(cellDic, hn, vn);
			if (t_cell != null) {
				if (t_cell.get_state() == 0) {
					t_rv = true;
				}
			}

			return t_rv;
		}

		,
		// :: Cell 상태 변경 (CellPoint 사용)
		//		@Param(cellDic: CellDictionaryObject, hn: HorizontalNum, vn: VerticalNum, sn: StateNum)
		stateChange: function(cellDic, hn, vn, sn) {
			var t_cell = this.get_cell(cellDic, hn, vn);
			if (t_cell != null) {
				t_cell.set_state(sn);
			}
		}

	};

})();


// # ShapeData Class
(function() {
	if (window.ShapeData != undefined) {
		return;
	}

	// #
	window.ShapeData = {

		// ::
		p_get_sweetData: function(source, sn) {
			var t_rv = null;

			for (
				var
					t_sps = source.split('-'),
					t_la = t_sps.length,
					i = 0;
				i < t_la; i++
			) {
				var t_sp = t_sps[i];
				var t_lb = t_sp.length;
				for (var j = 0; j < t_lb; j++)
				{
					var t_ab = t_sp.charAt(j);
					if (t_ab == 'o')
					{
						var t_hn = j + 1;
						var t_vn = i + 1;
						var t_co = new CellObj(j + 1, i + 1, sn);

						if (t_rv == null) {
							t_rv = [];
						}
						t_rv.push(t_co);
					}
				}
			}

			return t_rv;
		}

		,
		// ::
		p_get_sweetData_all: function() {
			var t_rv = null;

			for (var t_la = this.TYPE_SOURCES.length,
					i = 0;
					i < t_la; i++)
			{
				var t_rvs = null;

				var t_ts = this.TYPE_SOURCES[i];
				for (var t_lb = t_ts.length,
					j = 0;
					j < t_lb; j++)
				{
					var t_ti = t_ts[j];

					if (t_rvs == null) {
						t_rvs = [];
					}
					t_rvs.push(this.p_get_sweetData(t_ti, i + 1));
				}

				if (t_rv == null) {
					t_rv = [];
				}
				t_rv.push(t_rvs);
			}

			return t_rv;
		}

		,
		// - 데이터 소스 이거만 수정하면 됨 (3차원 행렬)
		TYPE_SOURCES: [
		 	// Type 1
			[
				'xxxx-' +
				'oooo-' +
				'xxxx-' +
				'xxxx-'

				,
				'xoxx-' +
				'xoxx-' +
				'xoxx-' +
				'xoxx-'
			]

			,
			// Type 2
			[
				'xxx-' +
				'ooo-' +
				'xox-'

				,
				'xox-' +
				'oox-' +
				'xox-'

				,
				'xxx-' +
				'xox-' +
				'ooo-'

				,
				'xox-' +
				'xoo-' +
				'xox-'
			]

			,
			// Type 3
			[
				'xxx-' +
				'ooo-' +
				'oxx-'

				,
				'oox-' +
				'xox-' +
				'xox-'

				,
				'xxx-' +
				'xxo-' +
				'ooo-'

				,
				'xox-' +
				'xox-' +
				'xoo-'
			]

			,
			// Type 4
			[
				'xxx-' +
				'ooo-' +
				'xxo-'

				,
				'xox-' +
				'xox-' +
				'oox-'

				,
				'xxx-' +
				'oxx-' +
				'ooo-'

				,
				'xoo-' +
				'xox-' +
				'xox-'
			]

			,
			// Type 5
			[
				'xxx-' +
				'xoo-' +
				'oox-'

				,
				'oxx-' +
				'oox-' +
				'xox-'
			]

			,
			// Type 6
			[
				'xxx-' +
				'oox-' +
				'xoo-'

				,
				'xxo-' +
				'xoo-' +
				'xox-'
			]

			,
			// Type 7
			[
				'oo-' +
				'oo-'
			]
		]

	};

	window.ShapeData.TYPES = window.ShapeData.p_get_sweetData_all();

})();


// # ShapeObj Class
(function() {
	if (window.ShapeObj != undefined) {
		return;
	}

	// #
	var t_class = window.ShapeObj = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	//
	t_class.prototype = {

		// :: 초기화
		p_initOnce: function(hn, vn, sn) {
			this.hn = hn;
			this.vn = vn;
			this.sn = sn;
		}

		,
		// :: 출력
		toString: function() {
			var t_str =
				'hn=' + this.hn + ', ' +
				'vn=' + this.vn + ', ' +
				'sn=' + this.sn;
			return t_str;
		}

		,
		// :: 복제
		clone: function() {
			var t_rv = new CellObj(this.hn, this.vn, this.sn);
			return t_rv;
		}

	};

})();