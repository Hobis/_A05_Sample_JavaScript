(function() {
	if (window.CellCanvas != undefined) {
		return;
	}

	//
	var t_class = window.CellCanvas = function() {
		if (this instanceof arguments.callee) {
			this.p_initOnce.apply(this, arguments);
		}
		else {
			throw new Error('This function is allowed only instances.');
		}
	};

	// #
	t_class.prototype = {

		// ::
		p_initOnce: function(w, h) {
			//
			var t_DIV_STR =
				'<div style="position: absolute; left: 0px; top: 0px; ' +
					'overflow: hidden;></div>';

			this._rect = jQuery(t_DIV_STR);
			this._rect.css('background-color', Cell._RECT_COLORS[0]);
			this._rect.css('width', w + 'px');
			this._rect.css('height', h + 'px');

			this._stateNum = 0;
		}

	};
})();
